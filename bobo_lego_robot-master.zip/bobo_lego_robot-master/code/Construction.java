package project_bobo;

//Importation classe

public class Construction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void Contruction() {
		//Classe qui sert a construire des formes 
		
		// 1 : Avancer 
		
		// 2 : Former les images de construction 
		
		//********************* Enfaite je ne sais pas ...... **********************************//
	}
}